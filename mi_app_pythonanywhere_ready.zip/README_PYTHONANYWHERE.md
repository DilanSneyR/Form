Preparado para PythonAnywhere
----------------------------

Cambios realizados (sin modificar la lógica del código original):
- Si existía 'appy.py', se renombró/copiÃ³ a 'app.py' en la misma carpeta.
- Se creó 'requirements.txt' con Flask==2.2.5.
- Archivo adicional: este README con instrucciones WSGI.

Instrucciones rápidas para PythonAnywhere:
1. Sube la carpeta del proyecto al directorio /home/TU_USUARIO/mi_app
2. Crea y activa un virtualenv, luego instala dependencias:
   mkvirtualenv flaskenv --python=python3.10
   workon flaskenv
   pip install -r /home/TU_USUARIO/mi_app/requirements.txt
3. En la pestaña Web > WSGI configuration file, añade algo como:
   import sys, os
   path = '/home/TU_USUARIO/mi_app'
   if path not in sys.path:
       sys.path.append(path)
   from app import app as application
4. Si usas SQLite y ya tienes database.db, súbelo también. Si no, SQLite creará el archivo pero debes asegurar que tu código crea las tablas (CREATE TABLE IF NOT EXISTS ...).

Notas sobre el contenido del archivo app.py (primeros 4000 caracteres mostrados en paralelo):

